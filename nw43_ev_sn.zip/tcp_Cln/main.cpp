//
//
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4996)

#pragma comment(lib, "ws2_32.lib")

#include <winsock2.h>
#include <windows.h>
#include <process.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define	MAX_BUF		8192


char	sPt[32]="20000";
char	sIp[64]="127.0.0.1";

void LogGetLastError(int hr);


SOCKET				g_scHost=0;				// ����
SOCKADDR_IN			g_sdHost={0};			// ���� ��巹��
WSAEVENT			g_seHost=0;				// Event
INT					g_nBuf=0;				// recorded byte
char				g_sBuf[MAX_BUF+4]={0};	// send buffer

HANDLE				g_hThSnd;				//
HANDLE				g_hThRcv;				//
DWORD WINAPI		WorkRcv(void*);			// �񵿱� ������ ������
DWORD WINAPI		WorkSnd(void*);

CRITICAL_SECTION	m_CS;					// �Ӱ� ����



int main()
{
	// �Ӱ� ���� �ʱ�ȭ
	InitializeCriticalSection(&m_CS);


	WSADATA		wsData={0};
	INT			hr =-1;

	printf("Starting Client.\nPort: %s\n", sPt);

	if(0 != WSAStartup(MAKEWORD(2, 2), &wsData))
		return -1;


	g_scHost = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	if(INVALID_SOCKET == g_scHost)
		return -1;


	// Nagle off
	int v = 1;
	hr = setsockopt(g_scHost, IPPROTO_TCP, TCP_NODELAY, (char*)&v, sizeof(v));
	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();
		LogGetLastError(hr);
		return -1;
	}


	memset(&g_sdHost, 0, sizeof(g_sdHost));
	g_sdHost.sin_family      = AF_INET;
	g_sdHost.sin_addr.s_addr = inet_addr(sIp);
	g_sdHost.sin_port        = htons( atoi(sPt) );


	// event ��ü ����
	g_seHost = WSACreateEvent();

	// <����, �̺�Ʈ, �̺�Ʈ ���� ����> ���ε�
	// ������ �ڵ����� Non-blocking���� ��ȯ
	hr = WSAEventSelect(g_scHost, g_seHost, FD_CONNECT|FD_READ|FD_WRITE|FD_CLOSE);


	hr = connect(g_scHost, (SOCKADDR*)&g_sdHost, sizeof(SOCKADDR_IN));

	// EventSelect���� �ڵ����� Non-blocking �𵨷� �ٲ�ϴ�.
	// ���� ������ �߻����� �� ��Ȯ�ϰ� �̰��� ��������
	// WSAGetLastError() �Լ��� ���ؼ� Ȯ���ؾ� �մϴ�.
	if(SOCKET_ERROR ==hr)
	{
		Sleep(10);
		hr = WSAGetLastError();

		if(WSAEWOULDBLOCK !=hr)
		{
			return -1;
		}
	}

	//������ �۽ſ� ������ ����. �Ͻ� ���� ����
	g_hThSnd = (HANDLE)_beginthreadex(NULL, 0
					, (unsigned (__stdcall*)(void*))WorkSnd
					, NULL, CREATE_SUSPENDED, NULL);

	// �񵿱� ������ ���������
	g_hThRcv = (HANDLE)_beginthreadex(NULL, 0
					, (unsigned (__stdcall*)(void*))WorkRcv
					, NULL, 0, NULL);



	while(g_scHost)
	{
		INT		hr = 0;
		INT		iLen=0;					//
		char	sSnd[MAX_BUF]={0};		// �׽�Ʈ�� �۽� ����

		// ä��
		fgets(sSnd, MAX_BUF, stdin);
		iLen = strlen(sSnd);

		if(1 >iLen)
			continue;

		if('\n' == sSnd[iLen-1])
		{
			sSnd[iLen-1] =0;
			--iLen;
		}

		/*
		// �׽�Ʈ
		static int nTstValue = 0;

		Sleep(100);
		++nTstValue;
		sprintf(sSnd, "ClientMsg- %4d", nTstValue);
		iLen = strlen(sSnd);
		*/


		if(0 >= iLen)
			continue;


		// �۽� ���ۿ� ä���
		EnterCriticalSection(&m_CS);
			g_nBuf= iLen;
			memcpy(g_sBuf, sSnd, iLen);
		LeaveCriticalSection(&m_CS);

		// �۽� ������ �簳
		ResumeThread(g_hThSnd);
	}


	shutdown(g_scHost, SD_BOTH);
	closesocket(g_scHost);

	g_scHost = 0;

	SetEvent(g_seHost);

	// ������ �ڵ� ����
	CloseHandle(g_hThRcv);
	CloseHandle(g_hThSnd);

	WSACleanup();

	DeleteCriticalSection(&m_CS);

	return 0;
}



DWORD WINAPI WorkSnd(void* pParam)
{
	while(g_scHost)
	{
		EnterCriticalSection(&m_CS);

		INT	hr = 0;
		INT iTot=0;			// Total Sending Data
		INT iLen=g_nBuf;	//

		while(iTot<iLen)
		{
			char* p = g_sBuf + iTot;

			hr = send(g_scHost, p, iLen-iTot, 0);
			if(SOCKET_ERROR == hr)
			{
				hr = WSAGetLastError();
				if(WSAEWOULDBLOCK == hr)
					continue;

				// socket error
				hr = -1;
				printf("Network closeclosed\n");
				break;
			}

			iTot += hr;
		}

		// send buffer clear
		memset(g_sBuf, 0, g_nBuf);
		g_nBuf = 0;

		LeaveCriticalSection(&m_CS);


		if(FAILED(hr))
			goto END;

		// �۽� ������ �Ͻ� ����
		HANDLE hThread = GetCurrentThread();
		SuspendThread(hThread);
	}

END:
	_endthreadex(0);
	return 0;
}



DWORD WINAPI WorkRcv(void* pParam)
{
	while(g_scHost)
	{
		INT	hr = 0;
		WSANETWORKEVENTS wnE={0};


		// event�� �߻��� ������ ��ٸ�
		//hr = WaitForSingleObject(g_seHost, FALSE, INFINITE);
		hr = WSAWaitForMultipleEvents(1, &g_seHost, FALSE, WSA_INFINITE, FALSE);
		if(0 == g_scHost)
			break;


		// ����
		if(WSA_WAIT_FAILED == hr)
		{
			printf("Err::WSAWaitForMultipleEvents\n");
			hr = WSAGetLastError();
			LogGetLastError(hr);
			break;
		}

		// event ����
		hr = WSAEnumNetworkEvents(g_scHost, g_seHost, &wnE);
		if(SOCKET_ERROR == hr)
		{
			printf("Err::WSAEnumNetworkEvents\n");

			hr = WSAGetLastError();
			LogGetLastError(hr);
			break;
		}


		////////////////////////////////////////////////////////////////////////
		// event process

		// connection event
		if( FD_CONNECT & wnE.lNetworkEvents)
		{
			if(wnE.iErrorCode[FD_CONNECT_BIT])
			{
				hr = wnE.iErrorCode[FD_CONNECT_BIT];
				LogGetLastError(hr);
				break;
			}

			printf("Connection Successed\n");
		}

		// Sending event
		else if( FD_WRITE & wnE.lNetworkEvents)
		{
		}

		// receive event
		else if( FD_READ & wnE.lNetworkEvents)
		{
			char sRcv[MAX_BUF+4]={0};

			INT iRcv = recv(g_scHost, sRcv, MAX_BUF, 0);

			if(0>iRcv)
			{
				hr = WSAGetLastError();
				if(WSAEWOULDBLOCK == hr)
					continue;

				printf("Network Close\n");
				break;
			}
			if(0 == iRcv)
			{
				printf("Network Close\n");
				break;
			}
			else
			{
				printf("Recv from server : %s\n", sRcv);
			}
		}

		// close event
		else if( FD_CLOSE & wnE.lNetworkEvents)
		{
			printf("Network Close\n");
			break;
		}

	}

	_endthreadex(0);

	return 0;
}



void LogGetLastError(int hr)
{
	char* lpMsgBuf;
	FormatMessage(
				FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM
				| FORMAT_MESSAGE_IGNORE_INSERTS
				, NULL, hr, 0, (LPSTR)&lpMsgBuf, 0, NULL );

	printf( "%s\n", lpMsgBuf);
	LocalFree( lpMsgBuf );
}

