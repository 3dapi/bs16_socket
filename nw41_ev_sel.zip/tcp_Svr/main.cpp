//
//
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4996)

#pragma comment(lib, "ws2_32.lib")

#include <winsock2.h>
#include <windows.h>
#include <process.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define	MAX_BUF		8192
#define	MAX_HOST	WSA_MAXIMUM_WAIT_EVENTS

char	sPt[32]="20000";

void LogGetLastError(int hr);



struct RemoteHost
{
	SOCKET		scH;						// socket
	SOCKADDR_IN	sdH;						// address
	WSAEVENT	seH;						// Event

	RemoteHost()
	{
		scH		= 0;
		memset(&sdH, 0, sizeof(SOCKADDR_IN));

		seH	= NULL;
	}

	void Set(SOCKET s, SOCKADDR_IN* d , WSAEVENT v)
	{
		scH		= s;
		memcpy(&sdH, d, sizeof(SOCKADDR_IN));
		seH	= v;
	}

	void Close()
	{
		if(0==scH)
			return;

		shutdown(scH, SD_BOTH);
		closesocket(scH);
		scH = 0;

		CloseHandle(seH);
		seH	 = NULL;
	}
};


SOCKET			g_scLstn=0;				// listen socket
WSAEVENT		g_seLstn=0;				// event
RemoteHost		g_rmHost[MAX_HOST];		// Host list: listen + client list

void	EchoMsg(char* s,int iLen);		// echo message



RemoteHost* FindHost(SOCKET scH)
{
	for(INT i=0; i<MAX_HOST; ++i)
	{
		if(scH == g_rmHost[i].scH)
			return &g_rmHost[i];
	}

	return NULL;
}


RemoteHost* FindNotUseHost()
{
	for(INT i=0; i<MAX_HOST; ++i)
	{
		if(0 >= g_rmHost[i].scH)
			return &g_rmHost[i];
	}

	return NULL;
}


void DeleteHost(SOCKET scH)
{
	if(0>=scH)
		return;

	for(INT i=0; i<MAX_HOST; ++i)
	{
		if(scH == g_rmHost[i].scH)
		{
			g_rmHost[i].Close();
			return;
		}
	}
}

void DeleteAllHost()
{
	for(INT i=0; i<MAX_HOST; ++i)
	{
		if(0 < g_rmHost[i].scH)
			g_rmHost[i].Close();
	}
}



int main()
{
	WSADATA		wsData={0};
	INT			hr =-1;

	printf("Starting Server.\nPort: %s\n", sPt);


	if(0 != WSAStartup(MAKEWORD(2, 2), &wsData))
		return -1;


	g_scLstn = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	if(INVALID_SOCKET == g_scLstn)
		return -1;

	SOCKADDR_IN	sdLstn={0};			// address

	sdLstn.sin_family      = AF_INET;
	sdLstn.sin_addr.s_addr = htonl(INADDR_ANY);
	sdLstn.sin_port        = htons( atoi(sPt) );

	hr = bind(g_scLstn, (SOCKADDR*)&sdLstn, sizeof(SOCKADDR_IN));

	if(SOCKET_ERROR == hr)
		return -1;


	// �̺�Ʈ ��ü ����
	g_seLstn = WSACreateEvent();


	// <����, �̺�Ʈ ��ü, �񵿱� ���� �̺�Ʈ ����(accept, close)> ���ε�.
	// ������ �ڵ����� Non-blocking���� ��ȯ
	hr = WSAEventSelect(g_scLstn, g_seLstn, FD_ACCEPT|FD_CLOSE);

	// Listen ���ϰ� �̺�Ʈ ���� ȣ��Ʈ ����Ʈ 0���� �߰�.
	g_rmHost[0].Set(g_scLstn, &sdLstn, g_seLstn);

	// Listen ����
	hr = listen(g_scLstn, SOMAXCONN);
	if(SOCKET_ERROR ==hr)
		return -1;


	while(1)
	{
		RemoteHost*		pHost = NULL;

		WSANETWORKEVENTS wnE={0};
		WSAEVENT		vEvn[MAX_HOST]={0};		// Event List
		SOCKET			vSck[MAX_HOST]={0};		// Socket List

		INT				hr = 0;
		INT				i  = 0, nLst=0;
		INT				nE=-1;


		// listen ����, Ŭ���̾�Ʈ�� ��� �̺�Ʈ�� ����Ʈ�� ����
		// listen ���� ����, Ŭ���̾�Ʈ�� ��� ������ ����Ʈ�� ����

		for(i=0; i<MAX_HOST; ++i)
		{
			if(0 == g_rmHost[i].scH)
				continue;

			vEvn[nLst] = g_rmHost[i].seH;
			vSck[nLst] = g_rmHost[i].scH;
			++nLst;
		}


		// Accept ������ ��Ʈ��ũ �̺�Ʈ�� ��ٸ���.
		//nE = WaitForMultipleObjects(nLst, vEvn, FALSE, WSA_INFINITE);
		nE = WSAWaitForMultipleEvents(nLst, vEvn, FALSE, WSA_INFINITE, FALSE);

		if(nE == WSA_WAIT_FAILED)
		{
			hr = WSAGetLastError();
			LogGetLastError(hr);
			break;
		}

		nE -= WSA_WAIT_EVENT_0;		// �ε��� ������

		for(i= nE; i<nLst; ++i)
		{
			hr = WSAWaitForMultipleEvents(1, &vEvn[i], TRUE, 0, FALSE);

			if( WSA_WAIT_FAILED  == hr || WSA_WAIT_TIMEOUT == hr)
				continue;


			// �̺�Ʈ ����
			hr = WSAEnumNetworkEvents(vSck[i], vEvn[i], &wnE);

			// get the host
			SOCKET scHost = vSck[i];
			pHost = FindHost(scHost);


			// WSAEnumNetworkEvents() �Լ��� ���� ��ȯ üũ
			if(SOCKET_ERROR == hr)
			{
				hr= WSAGetLastError();
				printf("WSAEnumNetworkEvents Error\n");


				// listen socket
				if(scHost == g_scLstn)
				{
					printf("Listen socket or Network Error\n");
					goto END;
				}

				pHost->Close();
				printf("Client Socket Close: %d\n", (int)scHost);

				continue;
			}


			////////////////////////////////////////////////////////////////////
			// Accept event
			if( FD_ACCEPT & wnE.lNetworkEvents)
			{
				SOCKET		scLstn = vSck[i];
				SOCKET		scCln;
				SOCKADDR_IN	sdCln;
				WSAEVENT	seCln;

				INT iSize = sizeof(SOCKADDR_IN);

				// accept()�Լ��� Ŭ���̾�Ʈ ����, �ּ� ���
				scCln = accept(scLstn, (SOCKADDR*)&sdCln, &iSize);

				// �̺�Ʈ ��ü ����
				seCln = WSACreateEvent();

				// ������ Ŭ���̾�Ʈ�� �񵿱�� ���� ���� �� �ֵ���
				// <����, �̺�Ʈ ��ü, �񵿱� ���� �̺�Ʈ ����> ���ε�
				WSAEventSelect(scCln, seCln, (FD_READ|FD_WRITE|FD_CLOSE));

				// ������� �ʴ� Host list�� �߰�
				pHost = FindNotUseHost();

				if(NULL == pHost)
				{
					printf("There is no empty element for client.\n");

					// disconnect the client
					shutdown(scCln, SD_BOTH);
					closesocket(scCln);
				}
				else
					pHost->Set(scCln, &sdCln, seCln);


				continue;
			}


			////////////////////////////////////////////////////////////////////
			// I/O event

			// Sending event
			if( FD_WRITE & wnE.lNetworkEvents)
			{
			}

			// closing event
			else if( FD_CLOSE & wnE.lNetworkEvents)
			{
				pHost->Close();
				printf("Client Close: %d\n", (int)scHost);
			}

			// receive event
			else if( FD_READ & wnE.lNetworkEvents)
			{
				INT		iRcv = 0;
				char	bufRcv[MAX_BUF+4]={0};

				// ������ ����
				iRcv=recv(vSck[i], bufRcv, MAX_BUF, 0);

				if(0 > iRcv)
				{
					hr = WSAGetLastError();

					if(WSAEWOULDBLOCK != hr)
					{
						pHost->Close();
						printf("Client Close: %d\n", (int)scHost);
						LogGetLastError(hr);

						continue;
					}
				}
				else if(0 == iRcv)
				{
					pHost->Close();
					printf("Client Close: %d\n", (int)scHost);
				}
				else
				{
					printf("Recv from Client : %d %s\n", (int)scHost, bufRcv);

					char	bufSnd[MAX_BUF+4]={0};
					INT		iLen=0;

					sprintf(bufSnd, "%5d> %s", (int)scHost, bufRcv);
					iLen = strlen(bufSnd);

					EchoMsg(bufSnd, iLen);		// echo message
				}
			}// else if FD_READ
		}// for
	}// while

END:
	DeleteAllHost();
	WSACleanup();

	return 0;
}



void EchoMsg(char* s, int iLen)
{
	INT		iSnd= 0;
	INT		iTot= 0;

	// ���� �����͸� ������ ��� Ŭ���̾�Ʈ�� ����
	// listen socket ����. 1���� ����
	for(INT i=1; i<MAX_HOST; ++i)
	{
		RemoteHost* pCln = &g_rmHost[i];

		if(0 == pCln->scH)
			continue;

		iSnd= 0;
		iTot= 0;

		while(iTot<iLen)
		{
			char* p = s + iTot;

			iSnd = send(pCln->scH, p, iLen-iTot, 0);

			if(SOCKET_ERROR == iSnd)
			{
				iSnd = WSAGetLastError();
				if(WSAEWOULDBLOCK == iSnd)
					continue;

				// ���� error. client�� list���� ����
				pCln->Close();
				break;
			}

			iTot += iSnd;
		}
	}
}



void LogGetLastError(int hr)
{
	char* lpMsgBuf;
	FormatMessage(
				FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM
				| FORMAT_MESSAGE_IGNORE_INSERTS
				, NULL, hr, 0, (LPSTR)&lpMsgBuf, 0, NULL );

	printf( "%s\n", lpMsgBuf);
	LocalFree( lpMsgBuf );
}

