//
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4996)

#pragma comment(lib, "ws2_32.lib")

#include <vector>
using namespace std;

#include <winsock2.h>
#include <windows.h>
#include <process.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define	MAX_BUF		8192
#define MAX_HOST	WSA_MAXIMUM_WAIT_EVENTS

char	sPt[32]="20000";

void LogGetLastError(int hr);
void GetIp(char* s, SOCKET scH);


struct RemoteHost
{
	WSAOVERLAPPED	ol;
	WSABUF			wsBuf;

	SOCKET			scH;					// ����
	char			csBuf[MAX_BUF+4];		// �б� ����

	RemoteHost()
	{
		memset(&ol, 0 , sizeof(WSAOVERLAPPED));
		memset(csBuf, 0, sizeof(csBuf));
		wsBuf.len = MAX_BUF;
		wsBuf.buf = csBuf;

		scH		= 0;
	}

	RemoteHost(SOCKET s, WSAEVENT e)
	{
		memset(&ol, 0, sizeof(WSAOVERLAPPED));
		memset(csBuf, 0, sizeof(csBuf));
		wsBuf.len = MAX_BUF;
		wsBuf.buf = csBuf;

		ol.hEvent = e;
		scH       = s;
	}

	void SetEvent()	{	WSASetEvent(ol.hEvent);		}
	void ResetEvent(){	WSAResetEvent(ol.hEvent);	}

	void Close()
	{
		if(0 == scH)
			return;

		shutdown(scH, SD_BOTH);
		closesocket(scH);
		scH = 0;

		CloseHandle(ol.hEvent);
		ol.hEvent = NULL;

		memset(csBuf, 0, MAX_BUF);
	}
};

SOCKET					g_scLstn = 0;			// listen socket
vector<RemoteHost* >	g_vHost;				// host list
CRITICAL_SECTION		m_CS;					// critical section

DWORD WINAPI	WorkThread(void*);				// work thread

void			EchoMsg(char* s, int len);		// echo message



RemoteHost* FindHost(HANDLE e)
{
	if(NULL == e)
		return NULL;

	INT iSize = (INT)g_vHost.size();

	for(INT i=0; i<iSize; ++i)
	{
		if(e == g_vHost[i]->ol.hEvent)
			return g_vHost[i];
	}

	return NULL;
}

void DeleteHost(SOCKET scH)
{
	INT iSize = (INT)g_vHost.size();

	for(INT i=0; i<iSize; ++i)
	{
		if(scH == g_vHost[i]->scH)
		{
			delete g_vHost[i];
			g_vHost.erase( g_vHost.begin() + i);
			return;
		}
	}

}

void DeleteNotUseHost()
{
	EnterCriticalSection(&m_CS);
	vector<RemoteHost* >::iterator _F = g_vHost.begin();

	for( ; _F != g_vHost.end(); )
	{
		RemoteHost* p = (*_F);

		if(p && 0 >= p->scH)
		{
			delete p;
			_F = g_vHost.erase(_F);
			continue;
		}

		++_F;
	}

	LeaveCriticalSection(&m_CS);
}


void DeleteAllHost()
{
	INT iSize = (INT)g_vHost.size();

	for(INT i=0; i<iSize; ++i)
		delete g_vHost[i];

	g_vHost.clear();
}



int main()
{
	InitializeCriticalSection(&m_CS);

	WSADATA		wsData={0};
	INT			hr =-1;

	SOCKADDR_IN	sdLstn ={0};
	WSAEVENT	seLstn =NULL;

	printf("Starting Server.\nPort: %s\n", sPt);

	if(0 != WSAStartup(MAKEWORD(2, 2), &wsData))
		return -1;

	//scLstn = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, WSA_FLAG_OVERLAPPED);
	g_scLstn = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	if(INVALID_SOCKET == g_scLstn)
		return -1;


	sdLstn.sin_family      = AF_INET;
	sdLstn.sin_addr.s_addr = htonl(INADDR_ANY);
	sdLstn.sin_port        = htons(atoi(sPt) );

	hr = bind(g_scLstn, (SOCKADDR *)&sdLstn, sizeof(SOCKADDR_IN));
	if(SOCKET_ERROR == hr)
		return -1;

	hr = listen(g_scLstn, SOMAXCONN);
	if(SOCKET_ERROR ==hr)
		return -1;

	// create event and add the host list to zero index
	seLstn = WSACreateEvent();
	g_vHost.push_back( new RemoteHost(g_scLstn, seLstn) );

	// work ������ ����
	HANDLE hWork = (HANDLE)_beginthreadex(NULL, 0
							, (unsigned (__stdcall*)(void*))WorkThread
							, NULL, 0, NULL);

	// Work thread test..
	// work thread���� dead lock�� �߻����� �ʵ��� �̺�Ʈ�� signaled�� ��ȯ
	g_vHost[0]->SetEvent();

	while(1)
	{
		SOCKET		scCln= 0;
		SOCKADDR_IN	sdCln= {0};
		WSAEVENT	seCln= NULL;
		int			scSize= sizeof(sdCln);

		scCln = accept(g_scLstn, (SOCKADDR*)&sdCln, &scSize);
		if(INVALID_SOCKET == scCln)
			break;

		printf("New Client: %5d %s\n", (int)scCln, inet_ntoa(sdCln.sin_addr));


		// ȣ��Ʈ ����Ʈ�� �߰��� �� �ִ� �� �˻�.
		if(MAX_HOST <= (int)g_vHost.size() )
		{
			printf("There is no empty element for client.\n");

			// disconnect the client
			shutdown(scCln, SD_BOTH);
			closesocket(scCln);
		}

		// Event�� Notify �ϱ� ���� ������ Ŭ���̾�Ʈ���� ���� ��ȣ�� ����
		char sId[128]={0};
		sprintf(sId, "Connected: %d", (int)scCln);
		send(scCln, sId, strlen(sId), 0);


		// Nagle off
		int v = 1;
		hr = setsockopt(scCln, IPPROTO_TCP, TCP_NODELAY, (char*)&v, sizeof(v));
		if(SOCKET_ERROR == hr)
			hr = WSAGetLastError();



		// read�� �̺�Ʈ ����
		seCln		= WSACreateEvent();

		RemoteHost* pCln = new RemoteHost(scCln, seCln);
		DWORD		dFlag=0;
		DWORD		dTran= 0;

		// �񵿱� ����� ��û
		//hr = ReadFile((HANDLE)pCln->scH, pCln->csBuf, MAX_BUF, &dTran, &pCln->ol);
		hr = WSARecv(pCln->scH, &pCln->wsBuf, 1, &dTran, &dFlag, &pCln->ol, NULL);
		if(SOCKET_ERROR == hr)
		{
			hr =  WSAGetLastError();
			if(WSA_IO_PENDING != hr && WSAEWOULDBLOCK != hr)
			{
				LogGetLastError(hr);
				delete pCln;
				continue;
			}
		}

		// add the host list
		g_vHost.push_back(pCln);

		// work thread�� Ŭ���̾�Ʈ �߰����� �˸�
		g_vHost[0]->SetEvent();
	}


	CloseHandle(hWork);


	// ���� ����
	WSACleanup();
	DeleteCriticalSection(&m_CS);

	return 0;
}

// �񵿱� ����� �Ϸ�  ó�� �Լ�
DWORD WINAPI WorkThread(void* pParam)
{
	while(1)
	{
		RemoteHost*		pHost = NULL;

		WSAEVENT		vEvn[MAX_HOST]={0};		// Event List

		INT				hr = 0;
		INT				i  = 0, nLst=0;
		INT				nE =-1;

		// listen ����, Ŭ���̾�Ʈ�� ��� �̺�Ʈ�� ����Ʈ�� ����
		for(i=0; i<(int)g_vHost.size(); ++i)
		{
			RemoteHost* p =  g_vHost[i];
			if(0 == p->scH)
				continue;

			vEvn[nLst] = p->ol.hEvent;
			++nLst;
		}

		// ��ȣ ���� �̺�Ʈ ��ٸ�
		nE = WSAWaitForMultipleEvents(nLst, vEvn, FALSE, WSA_INFINITE, FALSE);
		if(nE == WSA_WAIT_FAILED)
			continue;

		nE -= WSA_WAIT_EVENT_0;		// �ε��� ������

		for(i= nE; i<nLst; ++i)		// find the signaled event
		{
			hr = WSAWaitForMultipleEvents(1, &vEvn[i], TRUE, 0, FALSE);
			if( WSA_WAIT_FAILED  == hr || WSA_WAIT_TIMEOUT == hr)
				continue;


			// get the host
			pHost = FindHost(vEvn[i]);
			if(NULL == pHost)
				continue;

			SOCKET scHost = pHost->scH;


			// event to non-signal
			pHost->ResetEvent();

			// listen socket
			if(g_scLstn == scHost)
				continue;


			// other client list process

			// �񵿱� ����� ��� Ȯ��
			DWORD	dFlag=0;
			DWORD	dTran= 0;
			hr = WSAGetOverlappedResult(scHost, &pHost->ol, &dTran, FALSE, &dFlag);

			if(FALSE == hr || 0 == dTran)
			{
				pHost->Close();
				printf("Disconnect Client: %d\n", (int)scHost);
				continue;
			}

			// receive data
			if(0<dTran)
			{
				printf("Recv from Client : %d %s\n", (int)scHost, pHost->csBuf);

				// test message
				char	sBufBuf[MAX_BUF]={0};
				sprintf(sBufBuf, "%5d : %s", (int)scHost, pHost->csBuf);

				// send the message to all client
				EchoMsg(sBufBuf, strlen(sBufBuf) );
			}



			// clear the transfer buffer
			memset(pHost->csBuf, 0, MAX_BUF);


			// �ٽ� ��û
			dFlag=0; dTran= 0;

			//hr = ReadFile((HANDLE)scHost, &pHost->csBuf, MAX_BUF, &dTran, &pHost->ol);
			hr = WSARecv(scHost, &pHost->wsBuf, 1, &dTran, &dFlag, &pHost->ol, NULL);
			if(SOCKET_ERROR == hr)
			{
				hr =  WSAGetLastError();
				if(WSA_IO_PENDING != hr && WSAEWOULDBLOCK != hr)
				{
					LogGetLastError(hr);
					pHost->Close();
				}
			}
		}

		DeleteNotUseHost();
	}

	_endthreadex(0);
	return 0;
}

void EchoMsg(char* s, int iLen)
{
	EnterCriticalSection(&m_CS);

	INT	hr = 0;
	INT iSize = (INT)g_vHost.size();

	for(INT i=1; i<iSize; ++i)
	{
		RemoteHost* pCln = g_vHost[i];
		if(0 >= pCln->scH)
			continue;

		WSABUF	wsBuf={0};
		DWORD	dSent=0;


		wsBuf.buf = s;
		wsBuf.len = iLen;
		//hr = send(pCln->scH, s, iLen, 0);
		hr = WSASend(pCln->scH, &wsBuf, 1, &dSent, 0, NULL, NULL);
		if(SOCKET_ERROR == hr)
		{
			hr =  WSAGetLastError();
			if(WSA_IO_PENDING != hr && WSAEWOULDBLOCK != hr)
			{
				LogGetLastError(hr);
				pCln->Close();
			}
		}
	}

	LeaveCriticalSection(&m_CS);
}



void LogGetLastError(int hr)
{
	char* lpMsgBuf;
	FormatMessage(
				FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM
				| FORMAT_MESSAGE_IGNORE_INSERTS
				, NULL, hr, 0, (LPSTR)&lpMsgBuf, 0, NULL );

	printf( "%s\n", lpMsgBuf);
	LocalFree( lpMsgBuf );
}



void GetIp(char* s, SOCKET scH)
{
	int size = sizeof(SOCKADDR_IN);
	SOCKADDR_IN sdH ={0};
	getpeername(scH, (SOCKADDR *)&sdH, &size);
	strcpy(s, inet_ntoa(sdH.sin_addr) );
}

