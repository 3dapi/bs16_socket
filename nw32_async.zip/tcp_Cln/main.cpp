//
//
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4996)

#pragma comment(lib, "ws2_32.lib")

#include <winsock2.h>
#include <windows.h>
#include <process.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define	MAX_BUF		8192


char	sPt[32]="20000";
char	sIp[64]="127.0.0.1";

SOCKET		g_scHost=0;									// ����
SOCKADDR_IN g_sdHost={0};								// ���� ��巹��


// ����ڰ� ������ ��Ʈ��ũ �޽���
#define WM_SOCKET_NOTIFY    (WM_USER+1000)


LRESULT	WINAPI WndProc(HWND, UINT, WPARAM, LPARAM);		// Window Message Callback Function
LRESULT        NetProc(HWND, UINT, WPARAM, LPARAM);		// Network Message Procedure

void	CloseSocket();


int main()
{
	// ������ ����
	char	sCls[128]="AsycSelect Client";
	HINSTANCE hInst	= GetModuleHandle(NULL);

	WNDCLASS wc = {0};
	wc.style        = CS_CLASSDC;
	wc.lpfnWndProc  = WndProc;
	wc.hInstance    = hInst;
	wc.hCursor      = LoadCursor(NULL,IDC_ARROW);
	wc.hbrBackground= (HBRUSH)GetStockObject(WHITE_BRUSH);
	wc.lpszClassName= sCls;

	RegisterClass( &wc );

	HWND hWnd = CreateWindow( sCls
		, sCls
		, WS_OVERLAPPEDWINDOW| WS_VISIBLE
		, CW_USEDEFAULT, CW_USEDEFAULT
		, 480, 320
		, NULL, NULL
		, hInst, NULL );

	ShowWindow( hWnd, SW_SHOW );
	UpdateWindow( hWnd );





	// ��Ʈ��ũ �ڵ带 �߰�
	WSADATA		wsData={0};
	INT			hr =-1;

	printf("Starting Client.\nPort: %s\n", sPt);

	if(0 != WSAStartup(MAKEWORD(2, 2), &wsData))
		return -1;


	g_scHost = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	if(INVALID_SOCKET == g_scHost)
		return -1;


	memset(&g_sdHost, 0, sizeof(g_sdHost));
	g_sdHost.sin_family      = AF_INET;
	g_sdHost.sin_addr.s_addr = inet_addr(sIp);
	g_sdHost.sin_port        = htons( atoi(sPt) );

	// AsycSelect�� ����. connect�Լ� ȣ�� ���� AsycSelect��
	// �����ϸ� ���� �̺�Ʈ�� ���� �� ����
	hr = WSAAsyncSelect(g_scHost, hWnd, WM_SOCKET_NOTIFY
						, FD_CONNECT|FD_WRITE|FD_READ|FD_CLOSE);

	hr = connect(g_scHost, (SOCKADDR*)&g_sdHost, sizeof(SOCKADDR_IN));

	// AsyncSelect���� Non-blocking �𵨷� �ڵ� ��ȯ
	// ó�� ���̸� ������ ��ȯ. WSAGetLastError() �Լ��� ���� �Ǵ�
	if(SOCKET_ERROR ==hr)
	{
		Sleep(10);
		hr = WSAGetLastError();

		if(WSAEWOULDBLOCK !=hr)
			return -1;
	}



	// ������ �޽��� ó��
	MSG msg={0};

	while( WM_QUIT != msg.message )
	{
		if(GetMessage( &msg, NULL, 0U, 0U))
		{
			TranslateMessage( &msg );
			DispatchMessage( &msg );
		}
	}

	UnregisterClass( sCls, hInst);

	CloseSocket();

	WSACleanup();

	return 0;
}



LRESULT WINAPI WndProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch( msg )
	{
		case WM_KEYDOWN:
		{
			switch(wParam)
			{
				case VK_ESCAPE:
				{
					SendMessage(hWnd, WM_DESTROY, 0,0);
					break;
				}
			}

			return 0;
		}

		case WM_CLOSE:
		case WM_DESTROY:
		{
			PostQuitMessage( 0 );
			return 0;
		}

		// ��Ʈ��ũ �޽��� ó��
		case WM_SOCKET_NOTIFY:
		{
			NetProc(hWnd, msg, wParam, lParam);
			return 0;
		}

		case WM_RBUTTONDOWN:
		{
			// �׽�Ʈ�� ��Ŷ
			char		bufSnd[MAX_BUF]={0};
			static INT	nTstValue=0;

			++nTstValue;
			sprintf(bufSnd, "ClientMsg- %4d", nTstValue);

			INT iSnd=0;
			INT iTot=0;
			INT iLen = strlen(bufSnd);

			// ��Ŷ�� �� ������ �ȵ� �� �����Ƿ� ���� ���� �� ���� While�� ����
			while(iTot<iLen)
			{
				iSnd =send(g_scHost, bufSnd+iTot, iLen-iTot, 0);
				iTot += iSnd;
			}

			return 0;
		}
	}

	return DefWindowProc( hWnd, msg, wParam, lParam );
}



LRESULT NetProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	SOCKET	scHost	= (SOCKET)wParam;
	DWORD	dError	= WSAGETSELECTERROR(lParam);
	DWORD	dEvent	= WSAGETSELECTEVENT(lParam);

	INT		hr = 0;

	// ���� üũ
	if(dError)
	{
		if(FD_CONNECT == dEvent)
			SetWindowText(hWnd, "Connection Failed.");

		SetWindowText(hWnd, "Network Closed");
		SendMessage(hWnd, WM_DESTROY, 0,0);
		return 0;
	}

	// connection �޽���
	if(FD_CONNECT == dEvent)
	{
		SetWindowText(hWnd, "Connection Successed");
		HDC hDC= GetDC(hWnd);
			TextOut(hDC, 10, 10, "Try to R button down.", strlen("Try to L button down."));
		ReleaseDC(hWnd, hDC);

		return 0;
	}


	// �۽� �޽���
	if(FD_WRITE == dEvent)
	{
		return 0;
	}

	// ���� �޽���
	if(FD_READ == dEvent)
	{
		char sBufRcv[MAX_BUF+4]={0};
		INT iRcv=recv(scHost, sBufRcv, MAX_BUF, 0);

		// socket close
		if(SOCKET_ERROR == iRcv)
		{
			hr = WSAGetLastError();
			if(WSAEWOULDBLOCK != hr)
			{
				SetWindowText(hWnd, "Network Closed");
				SendMessage(hWnd, WM_DESTROY, 0,0);
			}
		}

		else if(0 == iRcv)
		{
			SetWindowText(hWnd, "Network Closed");
			SendMessage(hWnd, WM_DESTROY, 0,0);
		}

		if(0<iRcv)
		{
			sBufRcv[iRcv]=0;
			printf("Recv from server : %s\n", sBufRcv);
		}
	}

	// ���� ���� �޽���
	else if(FD_CLOSE == dEvent)
	{
		SetWindowText(hWnd, "Network Closed");
		SendMessage(hWnd, WM_DESTROY, 0,0);
	}

	return 0;
}



void CloseSocket()
{
	if(0 == g_scHost)
		return;

	shutdown(g_scHost, SD_BOTH);
	closesocket(g_scHost);

	g_scHost = 0;
}

