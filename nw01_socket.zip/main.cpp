//
//
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4996)


// Winsock �� ����ϱ� ���� ���̺귯��
#pragma comment(lib, "ws2_32.lib")

// winsock2.h ��������� Windows.h ������Ϻ��� �׻� �ռ��־�� �Ѵ�.
#include <winsock2.h>
#include <windows.h>

#include <stdio.h>


void LogGetLastError();
void LogGetLastError(int hr);


int main()
{
	WSADATA		wsData={0};
	int			hr = 0;

	////////////////////////////////////////////////////////////////////////////
	// Load WinSock DLL
	hr = WSAStartup(MAKEWORD(2, 2), &wsData);
	if(0 != hr)
		return -1;

	DWORD dProtoBuf=0;

	// ù ��°, �� ��° �μ��� NULL�� �����Ǿ� �־ �ܼ��� ũ�⸸ ���
	// �Լ� ȣ�� ��ü�� Error�� �Ǿ�� ��.
	hr = WSAEnumProtocols(NULL, NULL, &dProtoBuf);

	int nCnt = dProtoBuf/sizeof(WSAPROTOCOL_INFO);

	if(SOCKET_ERROR != hr || 0 == nCnt)
	{
		hr = WSAGetLastError();
		LogGetLastError(hr);
		return -1;
	}


	////////////////////////////////////////////////////////////////////////////
	// TCP, UDP�� ����� �� �ִ��� Ȯ��
	int*              proto    = new int[nCnt];
	WSAPROTOCOL_INFO* protoInf = new WSAPROTOCOL_INFO[nCnt];

	memset(proto   , 0, nCnt * sizeof(int) );
	memset(protoInf, 0, nCnt * sizeof(WSAPROTOCOL_INFO) );

	proto[0] = IPPROTO_TCP;
	proto[1] = IPPROTO_UDP;

	hr = WSAEnumProtocols(proto, protoInf, &dProtoBuf);

	delete [] proto;
	delete [] protoInf;

	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();
		LogGetLastError(hr);
		return -1;
	}


	////////////////////////////////////////////////////////////////////////////
	// TCP socket descriptor ����
	SOCKET scHost=0;
	scHost = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	//scHost = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, WSA_FLAG_OVERLAPPED);
	if(INVALID_SOCKET == scHost)
	{
		hr = WSAGetLastError();
		LogGetLastError(hr);
		return -1;
	}


	// network process



	////////////////////////////////////////////////////////////////////////////
	// release socket descriptor
	closesocket(scHost);


	////////////////////////////////////////////////////////////////////////////
	// Unload WinSock DLL
	WSACleanup();

	printf("The winsock environment is OK.\n");

	return 0;
}


void LogGetLastError()
{
	int hr = WSAGetLastError();

	char* lpMsgBuf;
	FormatMessage( 
				FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM
				| FORMAT_MESSAGE_IGNORE_INSERTS
				, NULL, hr, 0, (LPSTR)&lpMsgBuf, 0, NULL );

	printf( "%s\n", lpMsgBuf);
	LocalFree( lpMsgBuf );
}


void LogGetLastError(int hr)
{
	char* lpMsgBuf;
	FormatMessage( 
				FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM
				| FORMAT_MESSAGE_IGNORE_INSERTS
				, NULL, hr, 0, (LPSTR)&lpMsgBuf, 0, NULL );

	printf( "%s\n", lpMsgBuf);
	LocalFree( lpMsgBuf );
}

