//
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4996)

#include <windows.h>
#include <process.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define	MAX_BUF		4

void LogGetLastError(int hr);
int  GetSystemProcessorCount();


HANDLE			g_hFile = NULL;				// File Handle
DWORD			g_TotalSize= 0;				// total file size

// for read	buffer
OVERLAPPED		g_rOL   ={0};
char			g_rBuf[MAX_BUF+4]={0};		// Io Completion Buffer for receive

HANDLE			g_hIocp	 = NULL;			// IOCP Handle
DWORD	WINAPI	WorkThread(void*);			// Work ������


INT		AsyncRead();


int main()
{
	INT hr = 0;

	g_hFile = CreateFile("flag.txt"
						, GENERIC_READ | GENERIC_WRITE
						, 0
						, NULL
						, OPEN_ALWAYS
						, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_OVERLAPPED
						, NULL);

	if(g_hFile == INVALID_HANDLE_VALUE)
		return -1;

	if(0 == (g_TotalSize = GetFileSize(g_hFile, NULL)) )
		return -1;


	// IOCP ��ü ����
	g_hIocp = CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, 0, 0);
	if(NULL == g_hIocp)
		return -1;


	// 2 * processor ������ŭ Work ������ ����
	int nWrkPrc = 2 * GetSystemProcessorCount();
	for(int i=0; i<nWrkPrc; ++i)
	{
		HANDLE hThWrk = (HANDLE)_beginthreadex(NULL, 0
						, (unsigned (__stdcall*)(void*))WorkThread
						, NULL, 0, NULL);

		CloseHandle(hThWrk);
	}


	ULONG_PTR	pIoKey = (ULONG_PTR)&g_hFile;									// IO Key is File
	HANDLE		hRet   = CreateIoCompletionPort(g_hFile, g_hIocp, pIoKey, 0);	// <IOCP, File, key> ���̵�


	// �񵿱� read ��û
	hr = AsyncRead();
	if(FAILED(hr))
		return -1;


	while(g_hFile)
	{
		Sleep(10);
	}


	if(g_hFile)
		CloseHandle(g_hFile);

	CloseHandle(g_hIocp);

	return 0;
}


DWORD WINAPI WorkThread(void* pParam)
{
	INT			hr = 0;
	ULONG_PTR	pIoKey	= NULL;
	OVERLAPPED*	pOL		= NULL;
	DWORD		dTran	= 0;
	DWORD		OLType	= 0;


	while(g_hFile)
	{
		pIoKey	= NULL;
		pOL		= NULL;
		dTran	= 0;

		hr = GetQueuedCompletionStatus(
				g_hIocp							// Completion Port
			,	&dTran							// ���� �� ����Ʈ ��
			,	(PULONG_PTR)&pIoKey				// �Ϸ�Ű �ּ�
			,	(LPOVERLAPPED*)&pOL				// OVERLAPPED ����ü
			,	INFINITE
			);


		if(0 == hr)								// ����
		{
			hr = GetLastError();

			if(NULL == pOL && NULL == pIoKey)
				continue;

			break;
		}

		if(0 == dTran)							// Read complete
		{
			printf("Read complete.\n");
			break;
		}


		printf("%s", g_rBuf);					// ���� ���

		g_rOL.Offset += dTran;					// offset ����
		if(g_TotalSize <= g_rOL.Offset)			// ��ü ���� ũ�� ��
			break;

		Sleep(10);

		memset(g_rBuf, 0, MAX_BUF);				// ���� �ʱ�ȭ
		hr = AsyncRead();						// Read file ��û
		if(FAILED(hr))
			break;
	}

	CloseHandle(g_hFile);
	g_hFile = 0;

	_endthreadex(0);
	return 0;
}


int AsyncRead()
{
	int hr = 0;
	DWORD	dTran = 0;
	memset(g_rBuf, 0, MAX_BUF+4);

	// �񵿱� read ��û
	hr = ReadFile(g_hFile, g_rBuf, MAX_BUF, &dTran, &g_rOL);
	if(ERROR_SUCCESS == hr)
	{
		hr = GetLastError();
		if(ERROR_IO_PENDING != hr)
		{
			LogGetLastError(hr);
			return -1;
		}

		Sleep(10);
	}

	return 0;
}


int GetSystemProcessorCount()
{
	SYSTEM_INFO SystemInfo;
	GetSystemInfo(&SystemInfo);
	return (int)SystemInfo.dwNumberOfProcessors;
}


void LogGetLastError(int hr)
{
	char* lpMsgBuf;
	FormatMessage(
				FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM
				| FORMAT_MESSAGE_IGNORE_INSERTS
				, NULL, hr, 0, (LPSTR)&lpMsgBuf, 0, NULL );

	printf( "%s\n", lpMsgBuf);
	LocalFree( lpMsgBuf );
}
