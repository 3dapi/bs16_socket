//
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4996)

#include <windows.h>
#include <process.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define	MAX_BUF		16

void LogGetLastError(int hr);


HANDLE			g_hFile = NULL;				// File Handle
DWORD			g_TotalSize= 0;				// total file size
DWORD			g_TotalRead= 0;				// total read

// for read	buffer
OVERLAPPED		g_rOL   ={0};
char			g_rBuf[MAX_BUF+4]={0};		// Io Completion Buffer for receive

DWORD	WINAPI	WorkThread(void*);			// Work ������


int main()
{
	INT hr = 0;

	g_hFile = CreateFile("tiger.txt"
						, GENERIC_READ | GENERIC_WRITE
						, 0
						, NULL
						, OPEN_ALWAYS
						, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_OVERLAPPED
						, NULL);

	if(g_hFile == INVALID_HANDLE_VALUE)
		return -1;

	if(0 == (g_TotalSize = GetFileSize(g_hFile, NULL)) )
		return -1;


	g_rOL.hEvent =CreateEvent(NULL, FALSE, FALSE, NULL);
	

	// Work ������ ����
	HANDLE hWork = (HANDLE)_beginthreadex(NULL, 0
					, (unsigned (__stdcall*)(void*))WorkThread
					, NULL, 0, NULL);


	DWORD	dTran = 0;


	memset(g_rBuf, 0, MAX_BUF);										// buffer clear

	hr= ReadFile(g_hFile, g_rBuf, MAX_BUF, &dTran, &g_rOL);			// �񵿱� read ��û
	if(ERROR_SUCCESS == hr)
	{
		Sleep(10);
		hr = GetLastError();
		if(ERROR_IO_PENDING != hr)
		{
			LogGetLastError(hr);
			return -1;
		}
	}

	while(g_hFile)
	{
		Sleep(100);
	}

	if(g_hFile)
		CloseHandle(g_hFile);

	CloseHandle(g_rOL.hEvent);

	return 0;
}


DWORD WINAPI WorkThread(void* pParam)
{
	int		hr	 = 0;
	DWORD	dTran= 0;

	while(1)
	{
		hr = WaitForSingleObject(g_rOL.hEvent, INFINITE);			// ����� �ϷḦ ��ٸ�
		if(WAIT_FAILED == hr)
		{
			hr = GetLastError();
			LogGetLastError(hr);
			goto END;
		}

		hr = GetOverlappedResult(g_hFile, &g_rOL, &dTran, FALSE);	// �Ϸ� ��� �ؼ�. ���۵� ���� ���


		printf(g_rBuf);												// ���� ���

		g_TotalRead += dTran;										// �о�� ��ü ���� ����
		if(g_TotalSize <= g_TotalRead)								// ���� ���̺��� ũ�ų� ������ ����
			break;


		g_rOL.Offset += dTran;										// offset�� �ٽ� ����
		memset(g_rBuf, 0, MAX_BUF);									// buffer�� �ʱ�ȭ


		hr= ReadFile(g_hFile, g_rBuf, MAX_BUF, &dTran, &g_rOL);		// �񵿱� read ��û
		if(ERROR_SUCCESS == hr)
		{
			Sleep(10);
			hr = GetLastError();
			if(ERROR_IO_PENDING != hr)
			{
				LogGetLastError(hr);
				return -1;
			}
		}
	}

END:
	CloseHandle(g_hFile);
	g_hFile = 0;

	_endthreadex(0);
	return 0;
}


void LogGetLastError(int hr)
{
	char* lpMsgBuf;
	FormatMessage(
				FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM
				| FORMAT_MESSAGE_IGNORE_INSERTS
				, NULL, hr, 0, (LPSTR)&lpMsgBuf, 0, NULL );

	printf( "%s\n", lpMsgBuf);
	LocalFree( lpMsgBuf );
}

