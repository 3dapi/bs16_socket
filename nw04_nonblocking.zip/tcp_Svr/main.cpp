//
//
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4996)

#pragma comment(lib, "ws2_32.lib")

#include <winsock2.h>
#include <windows.h>
#include <process.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


char	sPt[32]="20000";

void LogGetLastError(int hr);


int main()
{
	WSADATA		wsData={0};
	SOCKET		scLstn=0;
	SOCKADDR_IN sdLstn={0};

	SOCKET		scCln=0;
	SOCKADDR_IN sdCln={0};
	INT			hr=-1;


	char sBufSnd[1024]="Welcome to network programming!!!";

	printf("Starting Server.\nPort: %s\n", sPt);


	// Load Winsock DLL
	if(0 != WSAStartup(MAKEWORD(2, 2), &wsData))
		return -1;


	// Listen ���� ����
	scLstn=socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if(INVALID_SOCKET == scLstn)
		return -1;


	// Listen ���� �ּ� �Ҵ�
	memset(&sdLstn, 0, sizeof(sdLstn));
	sdLstn.sin_family      = AF_INET;
	sdLstn.sin_addr.s_addr = htonl(INADDR_ANY);
	sdLstn.sin_port        = htons( atoi(sPt) );

	hr = bind(scLstn, (SOCKADDR*)&sdLstn, sizeof(SOCKADDR_IN));
	if(SOCKET_ERROR == hr)
		return -1;


	// Listen ����
	hr = listen(scLstn, SOMAXCONN);
	if( SOCKET_ERROR == hr)
		return -1;


	// listen socket�� Nonblocking ���� ����
	u_long nonBlocking =1;
	hr = ioctlsocket(scLstn, FIONBIO, &nonBlocking);
	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();
		LogGetLastError(hr);
	}


	while(1)
	{
		// ���� ��û ����
		int iSize=sizeof(SOCKADDR_IN);

		scCln=accept(scLstn, (SOCKADDR*)&sdCln, &iSize);

		if(INVALID_SOCKET == scCln)
		{
			hr = WSAGetLastError();

			// This error is returned from operations on nonblocking sockets that
			// cannot be completed immediately
			if( WSAEWOULDBLOCK != hr)
				goto END;

			continue;
		}

		// Ŭ���̾�Ʈ�� �����
		char* sIP = inet_ntoa( sdCln.sin_addr);
		printf("Connect Client IP: %s\n", sIP);

		//printf("Connect Client IP: %d.%d.%d.%d\n"
		//		, sdCln.sin_addr.S_un.S_un_b.s_b1
		//		, sdCln.sin_addr.S_un.S_un_b.s_b2
		//		, sdCln.sin_addr.S_un.S_un_b.s_b3
		//		, sdCln.sin_addr.S_un.S_un_b.s_b4 );


		// Ŭ���̾�Ʈ�� ����ϴ� ������ Nonblocking �������� ����
		u_long nonBlocking =1;
		hr = ioctlsocket(scCln, FIONBIO, &nonBlocking);
		if(SOCKET_ERROR == hr)
		{
			hr = WSAGetLastError();
			LogGetLastError(hr);
		}

		break;
	}


	// �׽�Ʈ ���
	static int iCnt =0;
	while(50>iCnt)
	{
		Sleep(100);

		++iCnt;
		sprintf(sBufSnd, "Network message %d", iCnt);

		// ������ �۽�
		send(scCln, sBufSnd, strlen(sBufSnd), 0);
	}


END:
	// ���� ����
	shutdown(scCln, SD_BOTH);
	closesocket(scCln);
	closesocket(scLstn);

	// Unload WinSock DLL
	WSACleanup();

	return 0;
}


void LogGetLastError(int hr)
{
	char* lpMsgBuf;
	FormatMessage( 
				FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM
				| FORMAT_MESSAGE_IGNORE_INSERTS
				, NULL, hr, 0, (LPSTR)&lpMsgBuf, 0, NULL );

	printf( "%s\n", lpMsgBuf);
	LocalFree( lpMsgBuf );
}

