//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by tcp_Cln.rc
//
#define IDD_CHAT                        101
#define IDC_IP                          1001
#define IDC_PORT                        1002
#define IDC_CON                         1003
#define IDC_DISCON                      1004
#define IDC_LSTCHAT                     1005
#define IDC_CHAT                        1006
#define IDC_SEND                        1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
