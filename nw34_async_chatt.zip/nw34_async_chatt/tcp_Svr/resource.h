//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by tcp_Svr.rc
//
#define IDD_SERVER                     101
#define IDC_EXIT                        1002
#define IDC_LIST                        1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
