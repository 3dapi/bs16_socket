//
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4996)

#include <windows.h>
#include <process.h>

#include <stdio.h>


// test thread.
DWORD WINAPI ThreadProc(void* pParam)
{
	//HANDLE	hCur = GetCurrentThread();
	//DWORD	dCur = GetCurrentThreadId();
	//dCur = GetThreadId(hCur);


	INT nCnt=0;

	while(++nCnt<20)
	{
		Sleep(200);

		printf("Thread Proc: %d\n", nCnt);
	}

	_endthreadex(0);

	return 0;
}


int main()
{
	// create thread
	HANDLE	hThread = NULL;
	DWORD	dThread = 0;
	
	hThread = (HANDLE)_beginthreadex(NULL, 0
								, (unsigned (__stdcall*)(void*))ThreadProc
								, NULL, 0, (unsigned*)&dThread);
	//hThread = (HANDLE)CreateThread(NULL, 0, ThreadProc, NULL, 0, NULL);


	//if(dThread != GetThreadId(hThread))
	//	return 0;


	INT nCnt=0;
	while(++nCnt<20)
	{
		Sleep(200);
		printf("Main Proc: %d\n", nCnt);
	}

	WaitForSingleObject(hThread, INFINITE);


	// Thread ���� ����
	//{
	//	DWORD	dExit=0;
	//	int hr = GetExitCodeThread(hThread, &dExit);
	//
	//	if(0 != hr && STILL_ACTIVE == dExit)
	//		TerminateThread(hThread, dExit);
	//}

	::CloseHandle(hThread);

	return 0;
}

