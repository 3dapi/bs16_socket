//
//
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4996)

#pragma comment(lib, "ws2_32.lib")

#include <vector>
using namespace std;

#include <winsock2.h>
#include <windows.h>
#include <process.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define	MAX_BUF		8192
#define	MAX_HOST	WSA_MAXIMUM_WAIT_EVENTS


char	sPt[32]="20000";

void LogGetLastError(int hr);


struct RemoteHost
{
	SOCKET		scH;						// socket
	SOCKADDR_IN sdH;						// address
	WSAEVENT	seH;						// event
	int			nBuf;						// recorded byte
	char		sBuf[MAX_BUF];				// Send buffer

	RemoteHost()
	{
		scH	= 0;
		seH	= NULL;
		memset(&sdH, 0, sizeof(SOCKADDR_IN));

		nBuf	= 0;
		memset(sBuf, 0, MAX_BUF);
	}

	RemoteHost(SOCKET s, SOCKADDR_IN* d, WSAEVENT e)
	{
		scH	= s;
		seH	= e;
		memcpy(&sdH, d, sizeof(SOCKADDR_IN));

		nBuf	= 0;
		memset(sBuf, 0, MAX_BUF);
	}

	~RemoteHost()
	{
		Close();
	}

	void Close()
	{
		if(0 == scH)
			return;

		shutdown(scH, SD_BOTH);
		closesocket(scH);
		scH = 0;

		CloseHandle(seH);
		seH = NULL;

		nBuf	= 0;
		memset(sBuf, 0, MAX_BUF);
	}
};


vector<RemoteHost* >	g_vHost;			// Host list

HANDLE			g_hThRcv = NULL;			//
DWORD WINAPI	WorkRcv(void*);				// �񵿱� ������ ������

void	EchoMsg(char* s, int len);



RemoteHost* FindHost(HANDLE e)
{
	if(NULL == e)
		return NULL;

	INT iSize = (INT)g_vHost.size();

	for(INT i=0; i<iSize; ++i)
	{
		if(e == g_vHost[i]->seH)
			return g_vHost[i];
	}

	return NULL;
}


void DeleteHost(SOCKET scH)
{
	INT iSize = (INT)g_vHost.size();

	for(INT i=0; i<iSize; ++i)
	{
		if(scH == g_vHost[i]->scH)
		{
			delete g_vHost[i];
			g_vHost.erase( g_vHost.begin() + i);
			return;
		}
	}

}

void DeleteNotUseHost()
{
	vector<RemoteHost* >::iterator _F = g_vHost.begin();

	for(; _F != g_vHost.end(); )
	{
		if(0 >= (*_F)->scH)
		{
			delete (*_F);
			_F = g_vHost.erase(_F);
			continue;
		}

		++_F;
	}
}


void DeleteAllHost()
{
	INT iSize = (INT)g_vHost.size();

	for(INT i=0; i<iSize; ++i)
		delete g_vHost[i];

	g_vHost.clear();
}



int main()
{
	WSADATA		wsData={0};
	INT			hr =-1;

	printf("Starting Server.\nPort: %s\n", sPt);


	if(0 != WSAStartup(MAKEWORD(2, 2), &wsData))
		return -1;

	SOCKET		scLstn	= 0;
	SOCKADDR_IN	sdLstn	= {0};
	WSAEVENT	seLstn  = NULL;

	scLstn = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	if(INVALID_SOCKET == scLstn)
		return -1;


	memset(&sdLstn, 0, sizeof(sdLstn));
	sdLstn.sin_family      = AF_INET;
	sdLstn.sin_addr.s_addr = htonl(INADDR_ANY);
	sdLstn.sin_port        = htons( atoi(sPt) );

	hr = bind(scLstn, (SOCKADDR*)&sdLstn, sizeof(SOCKADDR_IN));

	if(SOCKET_ERROR == hr)
		return -1;


	// �̺�Ʈ ��ü ����
	seLstn = WSACreateEvent();

	// <����, �̺�Ʈ, �̺�Ʈ ���� ����> ���ε�
	// ������ �ڵ����� Non-blocking���� ��ȯ
	hr = WSAEventSelect(scLstn, seLstn, FD_ACCEPT|FD_CLOSE);


	// Listen ���ϰ� �̺�Ʈ ���� ȣ��Ʈ ����Ʈ�� �߰�
	g_vHost.push_back(new RemoteHost(scLstn, &sdLstn, seLstn));


	// Listen ����
	hr = listen(scLstn, SOMAXCONN);
	if(SOCKET_ERROR ==hr)
		return -1;


	// �񵿱� ������ ������ ����
	g_hThRcv = (HANDLE)_beginthreadex(NULL, 0
					, (unsigned (__stdcall*)(void*))WorkRcv
					, NULL, 0, NULL);


	while(1)
	{
		// ���� ������ ����
		Sleep(1000);
	};


	// ������ �ڵ� ����
	CloseHandle(g_hThRcv);

	DeleteAllHost();

	WSACleanup();


	return 0;
}



DWORD WINAPI WorkRcv(void* pParam)
{
	while(1)
	{
		RemoteHost*		pHost = NULL;

		WSANETWORKEVENTS wnE={0};
		WSAEVENT		vEvn[MAX_HOST]={0};		// Event List

		INT				hr = 0;
		INT				i  = 0, nLst=0;
		INT				nE=-1;



		// clear the host list (not used)
		DeleteNotUseHost();

		// listen ����, Ŭ���̾�Ʈ�� ��� �̺�Ʈ�� ����Ʈ�� ����
		for(i=0; i<(int)g_vHost.size(); ++i)
		{
			RemoteHost* p =  g_vHost[i];
			if(0 == p->scH)
				continue;

			vEvn[nLst] = g_vHost[i]->seH;
			++nLst;
		}


		// Accept ������ ��Ʈ��ũ �̺�Ʈ�� ��ٸ���.
		nE = WSAWaitForMultipleEvents(nLst, vEvn, FALSE, WSA_INFINITE, FALSE);
		if(nE == WSA_WAIT_FAILED)
		{
			hr = WSAGetLastError();
			LogGetLastError(hr);
			break;
		}


		nE -= WSA_WAIT_EVENT_0;		// �ε��� ������

		for(i= nE; i<nLst; ++i)
		{
			hr = WSAWaitForMultipleEvents(1, &vEvn[i], TRUE, 0, FALSE);
			if( WSA_WAIT_FAILED  == hr || WSA_WAIT_TIMEOUT == hr)
				continue;


			// get the host
			pHost = FindHost(vEvn[i]);
			if(NULL == pHost)
				continue;

			SOCKET scHost = pHost->scH;

			// �̺�Ʈ ����
			hr = WSAEnumNetworkEvents(scHost, vEvn[i], &wnE);
			if(SOCKET_ERROR == hr)
			{
				hr= WSAGetLastError();
				printf("WSAEnumNetworkEvents Error\n");


				// listen socket
				if(scHost == g_vHost[0]->scH)
				{
					printf("Listen socket or Network Error\n");
					goto END;
				}

				pHost->Close();
				printf("Client Socket Close: %d\n", (int)scHost);

				continue;
			}


			////////////////////////////////////////////////////////////////////
			// Accept event
			if( FD_ACCEPT & wnE.lNetworkEvents)
			{
				SOCKET		scLstn = scHost;
				SOCKET		scCln;
				SOCKADDR_IN	sdCln;
				WSAEVENT	seCln;

				INT iSize = sizeof(SOCKADDR_IN);

				// accept()�Լ��� Ŭ���̾�Ʈ ����, �ּ� ���
				scCln = accept(scLstn, (SOCKADDR*)&sdCln, &iSize);

				// �̺�Ʈ ��ü ����
				seCln = WSACreateEvent();

				// ������ Ŭ���̾�Ʈ�� �񵿱�� ���� ���� �� �ֵ���
				// <����, �̺�Ʈ ��ü, �񵿱� ���� �̺�Ʈ ����> ���ε�
				WSAEventSelect(scCln, seCln, FD_READ|FD_WRITE|FD_CLOSE);

				// ������� �ʴ� Host list�� �߰�
				if(MAX_HOST <= (int)g_vHost.size() )
				{
					printf("There is no empty element for client.\n");

					// disconnect the client
					shutdown(scCln, SD_BOTH);
					closesocket(scCln);
				}
				else
					g_vHost.push_back(new RemoteHost(scCln, &sdCln, seCln));


				continue;
			}


			////////////////////////////////////////////////////////////////////
			// I/O event
			// Sending event
			if( FD_WRITE & wnE.lNetworkEvents)
			{
			}

			// closing event
			else if( FD_CLOSE & wnE.lNetworkEvents)
			{
				pHost->Close();
				printf("Client Close: %d\n", (int)scHost);
			}

			// receive event
			else if( FD_READ & wnE.lNetworkEvents)
			{
				INT		iRcv = 0;
				char	bufRcv[MAX_BUF+4]={0};


				iRcv=recv(scHost, bufRcv, MAX_BUF, 0);

				if(0 > iRcv)
				{
					hr = WSAGetLastError();

					if(WSAEWOULDBLOCK != hr)
					{
						pHost->Close();
						printf("Client Close: %d\n", (int)scHost);
						LogGetLastError(hr);

						continue;
					}
				}
				else if(0 == iRcv)
				{
					pHost->Close();
					printf("Client Close: %d\n", (int)scHost);
				}
				else
				{
					printf("Recv from Client : %d %s\n", (int)scHost, bufRcv);

					char	bufSnd[MAX_BUF+4]={0};
					INT		iLen=0;

					sprintf(bufSnd, "%5d> %s", (int)scHost, bufRcv);
					iLen = strlen(bufSnd);

					EchoMsg(bufSnd, iLen);		// echo message
				}
			}// else if FD_READ
		}// for
	}// while

END:
	DeleteAllHost();
	WSACleanup();

	return 0;
}



void EchoMsg(char* s, int iLen)
{
	INT		iSnd= 0;
	INT		iTot= 0;

	// ���� �����͸� ������ ��� Ŭ���̾�Ʈ�� ����
	// listen socket ����. 1���� ����
	for(INT i=1; i<(int)g_vHost.size(); ++i)
	{
		RemoteHost* pCln = g_vHost[i];

		if(0 == pCln->scH)
			continue;

		iSnd= 0;
		iTot= 0;

		while(iTot<iLen)
		{
			char* p = s + iTot;

			iSnd = send(pCln->scH, p, iLen-iTot, 0);

			if(SOCKET_ERROR == iSnd)
			{
				iSnd = WSAGetLastError();
				if(WSAEWOULDBLOCK == iSnd)
					continue;

				// ���� error. client�� list���� ����
				pCln->Close();
				break;
			}

			iTot += iSnd;
		}
	}
}



void LogGetLastError(int hr)
{
	char* lpMsgBuf;
	FormatMessage(
				FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM
				| FORMAT_MESSAGE_IGNORE_INSERTS
				, NULL, hr, 0, (LPSTR)&lpMsgBuf, 0, NULL );

	printf( "%s\n", lpMsgBuf);
	LocalFree( lpMsgBuf );
}

